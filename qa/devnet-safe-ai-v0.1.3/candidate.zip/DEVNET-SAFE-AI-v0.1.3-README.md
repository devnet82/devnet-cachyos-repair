# Devnet Safe AI v0.1.3 — QA-BLOCKED candidate

This candidate is rebuilt from the SHA256-verified v0.1.2 original (`fd227dfc54e26e10198ebc0623088aea7884fa62840b7999b32d8a2d0618a8ae`) without modifying the installed launcher, private configuration, or existing workspace.

## Focused fixes

1. **Ollama 9B response handling.** In the trusted host's allowlisted Unix-socket-to-Ollama HTTP gateway, incoming `/v1/chat/completions` requests for `qwen3.5:9b` receive `reasoning_effort: "none"` as a top-level JSON field. This is applied only after endpoint/model checks. Tools, messages, stream flag and all other request fields are preserved. Requests to `qwen3-coder:30b` and native Ollama endpoints are unchanged. This addresses the observed reasoning-only OpenCode session; live resolution is not yet verified.
2. **OpenCode V2 location-relative edit paths.** The prior policy authorised only `/workspace/*`, though V2 may check relative file resources such as `sample.txt`. The updated rule permits relative edits while retaining mandatory `external_directory: deny`, Bubblewrap's physical `/workspace` bind boundary, and explicit denials for sensitive state/system locations, Git controls and secret-like files. This change expands the internal edit rule and therefore **must undergo native sandbox security testing** before installation.

## Verified local/offline scope

The 30 original unit tests were rerun against the changed version, plus five new tests covering forwarded model JSON, denial invariants, and a live Unix-socket gateway. Total: 35/35 passing in an isolated test container without a live OpenCode/Ollama installation.

## Missing mandatory live acceptance scope

- GitHub-hosted genuine CachyOS VM boot and integration evidence for THIS exact archive.
- Actual OpenCode 9B creates a named text file; preserves content exactly; reports tool execution and does not stop at reasoning-only output.
- Actual OpenCode 30B delegate tool invocation, file editing and automatic model selection/unloading.
- Sandbox escape attempts, relative `../` paths, symlinks, hidden control and secret-file edits, network denial, game interruption, rollback.
- Full Master QA with deterministic independent evidence gate.

**FAIL-CLOSED: NO RELEASE APPROVAL / DO NOT INSTALL UNTIL ALL REQUIRED TESTS PASS.** No existing installation is overwritten by this archive. This is a staging candidate for QA, not a final upgrade.

## Source contents

- `devnet-safe-ai-v0.1.3.py`
- `test_devnet_safe_ai_v0.1.3.py`
- `v0.1.2-baseline-permissions.json` (policy baseline for tests)
- `SHA256SUMS`

Run offline regression tests with: `python3 test_devnet_safe_ai_v0.1.3.py`.

The original v0.1.2 install action refuses overwrites. This candidate likewise refuses to replace an existing launcher. Do not bypass the protection as a substitute for a tested upgrade procedure.
