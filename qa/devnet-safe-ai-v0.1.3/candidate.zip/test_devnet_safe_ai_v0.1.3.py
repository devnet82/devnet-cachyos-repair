import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

src = Path(__file__).with_name('devnet-safe-ai-v0.1.3.py')
spec = importlib.util.spec_from_file_location('devnet_safe', src)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class GatewayTests(unittest.TestCase):
    def body(self, model='qwen3.5:9b', **kw):
        return json.dumps({'model':model,'messages':[{'role':'user','content':'Hello'}],**kw}).encode()
    def test_allowed_readonly_endpoints(self):
        for u in ('/api/version','/api/tags','/v1/models'):
            with self.subTest(u=u): self.assertTrue(mod.allowed_http('GET',u,b''))
    def test_block_fallback_to_remote_urls(self):
        for u in ('https://evil.example/','//evil.example','/api/version?secret=1','/api/version#frag'):
            with self.subTest(u=u): self.assertFalse(mod.allowed_http('GET',u,b''))
    def test_block_model_management(self):
        for u in ('/api/pull','/api/create','/api/delete','/api/copy','/api/blobs/sha256-abcd','/api/push'):
            with self.subTest(u=u): self.assertFalse(mod.allowed_http('POST',u,self.body()))
    def test_block_nonallowlisted_methods(self):
        for method in ('PUT','DELETE','PATCH','CONNECT','HEAD','OPTIONS'):
            with self.subTest(method=method): self.assertFalse(mod.allowed_http(method,'/api/chat',self.body()))
    def test_allow_both_local_models(self):
        for m in ('qwen3.5:9b','qwen3-coder:30b'):
            for u in ('/v1/chat/completions','/api/chat','/api/generate','/api/show'):
                with self.subTest(model=m,url=u): self.assertTrue(mod.allowed_http('POST',u,self.body(m)))
    def test_disallow_3rd_party_model(self):
        for model in ('gpt-4','../../../etc/passwd','cloud/secret','qwen3-coder:30b:latest'):
            self.assertFalse(mod.allowed_http('POST','/api/chat',self.body(model)))
    def test_block_invalid_json(self):
        for raw in (b'',b'invalid',b'[]',b'{}',b'null'):
            self.assertFalse(mod.allowed_http('POST','/api/chat',raw))
    def test_block_remote_image(self):
        data=self.body(images=['http://attacker.example/private'])
        self.assertFalse(mod.allowed_http('POST','/api/chat',data))
    def test_block_remote_image_in_messages(self):
        data=json.dumps({'model':'qwen3.5:9b','messages':[{'role':'user','images':['file:///etc/shadow']}]}).encode()
        self.assertFalse(mod.allowed_http('POST','/api/chat',data))
    def test_fail_closed_large_body(self):
        self.assertFalse(mod.allowed_http('POST','/api/chat',b' '*(mod.MAX_BODY+1)))
    def test_block_get_with_payload(self):
        self.assertFalse(mod.allowed_http('GET','/api/tags',b'hi'))

class ConfigurationTests(unittest.TestCase):
    def setUp(self): self.c=mod.config()
    def test_default_model(self): self.assertEqual(self.c['model'],'ollama/qwen3.5:9b')
    def test_heavy_model(self): self.assertEqual(self.c['agents']['devnet-heavy']['model'],'ollama/qwen3-coder:30b')
    def test_model_argument_omission_rule(self):
        self.assertIn('NEVER supply a model argument',self.c['agents']['build']['system'])
    def test_location_relative_edits_and_boundary(self):
        p=self.c['permissions']
        self.assertIn({'action':'edit','resource':'*','effect':'allow'},p)
        self.assertIn({'action':'external_directory','resource':'*','effect':'deny'},p)
        for folder in ('/home/*','/run/*','/tmp/*','/usr/*','/etc/*','/proc/*','/dev/*'):
            self.assertIn({'action':'edit','resource':folder,'effect':'deny'},p)
        for protected in ('.opencode/*','*/.opencode/*','.git/*','*/.git/*','*.env*','*.pem','*id_ed25519*','*id_rsa*'):
            self.assertIn({'action':'edit','resource':protected,'effect':'deny'},p)
    def test_no_shell_tools(self): self.assertIn({'action':'shell','resource':'*','effect':'deny'},self.c['permissions'])
    def test_no_external_directory(self): self.assertIn({'action':'external_directory','resource':'*','effect':'deny'},self.c['permissions'])
    def test_no_web_tools(self):
        for name in ('webfetch','websearch'):
            self.assertIn({'action':name,'resource':'*','effect':'deny'},self.c['permissions'])
    def test_only_local_provider_allowed(self):
        self.assertEqual(self.c['policies'][:2],[{'action':'provider.use','resource':'*','effect':'deny'}, {'action':'provider.use','resource':'ollama','effect':'allow'}])
    def test_private_standalone_server(self):
        with patch.object(mod.os,'environ',{}):
            args=mod.sandbox_cmd(Path('/tmp/sock'),Path('/tmp/config'),'chat',None)
        self.assertIn('--standalone',' '.join(args))
    def test_bwrap_isolation_flags(self):
        with patch.object(mod.os,'environ',{}):
            args=mod.sandbox_cmd(Path('/tmp/sock'),Path('/tmp/config'),'doctor',None)
        for opt in ('--unshare-all','--die-with-parent','--clearenv','--tmpfs','--ro-bind'):
            self.assertIn(opt,args)
        # A private application state directory may legitimately reside UNDER HOME.
        # Verify mount boundaries, not the occurrence of HOME as a substring.
        self.assertNotIn(str(mod.HOME), args)  # No bind of the whole home.
        mount_pairs = [(args[i + 1], args[i + 2]) for i, x in enumerate(args[:-2])
                       if x in ('--bind', '--ro-bind', '--dev-bind')]
        self.assertIn((str(mod.STATE_HOME), '/home/agent'), mount_pairs)
        self.assertIn((str(mod.WORKSPACE), '/workspace'), mount_pairs)
        self.assertNotIn((str(mod.HOME), '/home/agent'), mount_pairs)
        self.assertFalse(any(source == str(mod.HOME) for source, _ in mount_pairs))
        self.assertIn('find /home -mindepth 1 -maxdepth 1 ! -name agent', ' '.join(args))
        self.assertNotIn('/mnt/devnet-ai',args)
    def test_dedicated_persistent_state_only(self):
        args=mod.sandbox_cmd(Path('/tmp/sock'),Path('/tmp/config'),'doctor',None)
        self.assertIn('/home/agent',args)
        self.assertIn('/workspace',args)
        self.assertNotIn(str(mod.HOME),args)


# Additional live Unix-domain socket tests (no external network access needed).
class FakeUpstream:
    def __init__(self,*a,**kw): self.called=False
    def request(self,method,path,body=None,headers=None): self.called=True
    def getresponse(self):
        class Reply:
            status=200
            done=False
            def getheader(self,name): return 'application/json' if name=='Content-Type' else None
            def read1(self,limit):
                if self.done: return b''
                self.done=True
                return b'{"version":"mock-local"}'
        return Reply()
    def close(self): pass

class LiveUnixGatewayTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.sock=Path(self.temp.name)/'local.sock'
        self.server=mod.start_gateway(self.sock)
        self.addCleanup(self.server.server_close)
        self.addCleanup(self.server.shutdown)
    def request(self,method,path,body=b''):
        import socket
        client=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        client.settimeout(3)
        client.connect(str(self.sock))
        self.addCleanup(client.close)
        data=f'{method} {path} HTTP/1.1\r\nHost: localhost\r\nContent-Length: {len(body)}\r\n\r\n'.encode()+body
        client.sendall(data)
        blocks=[]
        while True:
            x=client.recv(8192)
            if not x:break
            blocks.append(x)
        return b''.join(blocks)
    def test_forbidden_api_is_http_403(self):
        with patch.object(mod.http.client,'HTTPConnection',side_effect=RuntimeError('Forbidden API contacted upstream!')):
            r=self.request('POST','/api/pull',b'{}')
        self.assertIn(b'403',r.split(b'\r\n',1)[0])
    def test_inference_allowed_model_passes(self):
        with patch.object(mod.http.client,'HTTPConnection',FakeUpstream):
            r=self.request('POST','/v1/chat/completions',json.dumps({'model':'qwen3-coder:30b'}).encode())
        self.assertIn(b'200',r.split(b'\r\n',1)[0])
        self.assertIn(b'{"version":"mock-local"}',r)
    def test_not_allowed_model_fails_closed(self):
        with patch.object(mod.http.client,'HTTPConnection',side_effect=RuntimeError('Forbidden model upstream!')):
            r=self.request('POST','/api/chat',json.dumps({'model':'gpt-4'}).encode())
        self.assertIn(b'403',r.split(b'\r\n',1)[0])
    def test_nonlocal_url_rejected(self):
        with patch.object(mod.http.client,'HTTPConnection',side_effect=RuntimeError('Nonlocal URL upstream!')):
            r=self.request('GET','http://evil.example/secret')
        self.assertIn(b'403',r.split(b'\r\n',1)[0])


class LifecycleTests(unittest.TestCase):
    def test_game_pause_terminates_sandbox_process(self):
        from unittest.mock import MagicMock
        proc=MagicMock(pid=12345)
        proc.poll.return_value=None
        proc.wait.return_value=-15
        server=MagicMock()
        with patch.object(mod,'paths_safe'), patch.object(mod,'private_dir'), \
             patch.object(mod,'memory_ok'), patch.object(mod,'gaming_now',side_effect=[False,True]), \
             patch.object(mod,'start_gateway',return_value=server), \
             patch.object(mod,'sandbox_cmd',return_value=['dummy']), \
             patch.object(mod.subprocess,'Popen',return_value=proc), \
             patch.object(mod.os,'killpg') as kill, patch.object(mod,'stop_models') as unload:
            with self.assertRaisesRegex(mod.Blocked,'Gaming detected'):
                mod.run_sandbox('run','Hello')
            kill.assert_called_once_with(12345,mod.signal.SIGTERM)
            unload.assert_called()
            server.shutdown.assert_called_once()
            server.server_close.assert_called_once()

    def test_failing_guard_terminates_sandbox_process(self):
        from unittest.mock import MagicMock
        proc=MagicMock(pid=12346)
        proc.poll.return_value=None
        proc.wait.return_value=-15
        server=MagicMock()
        with patch.object(mod,'paths_safe'), patch.object(mod,'private_dir'), \
             patch.object(mod,'memory_ok'), patch.object(mod,'gaming_now',side_effect=[False,mod.Blocked('guard unavailable')]), \
             patch.object(mod,'start_gateway',return_value=server), \
             patch.object(mod,'sandbox_cmd',return_value=['dummy']), \
             patch.object(mod.subprocess,'Popen',return_value=proc), \
             patch.object(mod.os,'killpg') as kill, patch.object(mod,'stop_models') as unload:
            with self.assertRaisesRegex(mod.Blocked,'guard unavailable'):
                mod.run_sandbox('run','Hello')
            kill.assert_called_once_with(12346,mod.signal.SIGTERM)
            unload.assert_called()
            server.shutdown.assert_called_once()
            server.server_close.assert_called_once()


class MemoryPolicyTests(unittest.TestCase):
    def test_keepalive_cannot_be_unlimited(self):
        for ttl in ('-1','100h','5m',-1,5000):
            request=json.dumps({'model':'qwen3.5:9b','keep_alive':ttl}).encode()
            self.assertFalse(mod.allowed_http('POST','/api/chat',request),ttl)
    def test_short_keepalive_allowed(self):
        for ttl in ('30s','0s',0):
            request=json.dumps({'model':'qwen3-coder:30b','keep_alive':ttl}).encode()
            self.assertTrue(mod.allowed_http('POST','/api/chat',request),ttl)


class InferenceReasoningCompatibilityTests(unittest.TestCase):
    """Proxy-level contract checks: raw body delivered to upstream."""
    def payload(self,model,**extra):
        return json.dumps({'model': model, 'stream': True,
            'messages': [{'role':'user','content':'Create sample.txt'}],
            'tools': [{'type':'function','function':{'name':'write','parameters':{'type':'object'}}}],
            **extra}).encode('utf-8')

    def test_planner_disables_reasoning_to_restore_standard_content_and_tools(self):
        raw=self.payload(mod.PLANNER)
        out=json.loads(mod.inference_payload('POST','/v1/chat/completions',raw))
        self.assertEqual(out['reasoning_effort'],'none')
        self.assertTrue(out['stream'])
        self.assertEqual(out['messages'],json.loads(raw)['messages'])
        self.assertEqual(out['tools'],json.loads(raw)['tools'])

    def test_planner_overrides_untrusted_reasoning_setting(self):
        raw=self.payload(mod.PLANNER,reasoning_effort='high')
        self.assertEqual(json.loads(mod.inference_payload('POST','/v1/chat/completions',raw))['reasoning_effort'],'none')

    def test_other_model_and_native_endpoint_remain_byte_identical(self):
        raw=self.payload(mod.CODER)
        self.assertEqual(mod.inference_payload('POST','/v1/chat/completions',raw),raw)
        raw=self.payload(mod.PLANNER)
        for target in ('/api/chat','/api/generate','/api/show'):
            self.assertEqual(mod.inference_payload('POST',target,raw),raw)

    def test_gateway_and_shell_denials_unchanged(self):
        c=mod.config()
        baseline=json.loads(Path(__file__).with_name('v0.1.2-baseline-permissions.json').read_text())
        for action in ('shell','webfetch','websearch','external_directory'):
            self.assertEqual([x for x in c['permissions'] if x['action']==action],
                             [x for x in baseline if x['action']==action])
        for m,p,b in [('POST','/api/pull',b'{}'),('POST','/v1/chat/completions',self.payload('cloud/secret'))]:
            self.assertFalse(mod.allowed_http(m,p,b))

    def test_real_unix_gateway_forwards_modified_planner_body(self):
        import socket,tempfile
        with tempfile.TemporaryDirectory() as td:
            srv=mod.start_gateway(Path(td)/'ollama.sock')
            captured=[]
            class RecordingUpstream:
                def __init__(self,*a,**kw):pass
                def request(self,method,path,body=None,headers=None):
                    captured.append((method,path,json.loads(body),headers))
                def getresponse(self):
                    class Reply:
                        status=200
                        done=False
                        def getheader(self,name):return 'application/json' if name=='Content-Type' else None
                        def read1(self,limit):
                            if self.done:return b''
                            self.done=True
                            return b'{"ok":true}'
                    return Reply()
                def close(self):pass
            try:
                with patch.object(mod.http.client,'HTTPConnection',RecordingUpstream):
                    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as client:
                        client.settimeout(3)
                        client.connect(str(Path(td)/'ollama.sock'))
                        body=self.payload(mod.PLANNER)
                        client.sendall(f'POST /v1/chat/completions HTTP/1.1\r\nHost: localhost\r\nContent-Length: {len(body)}\r\n\r\n'.encode()+body)
                        response=bytearray()
                        while True:
                            block=client.recv(8192)
                            if not block:break
                            response.extend(block)
                        self.assertIn(b'200',response.split(b'\r\n',1)[0])
                self.assertEqual(len(captured),1)
                self.assertEqual(captured[0][2]['reasoning_effort'],'none')
                self.assertEqual(captured[0][2]['tools'],json.loads(body)['tools'])
            finally:
                srv.shutdown();srv.server_close()

if __name__=='__main__': unittest.main(verbosity=2)
