#!/usr/bin/env python3
"""Devnet Safe AI v0.1.3 — fail-closed rootless OpenCode launcher.

Scope: isolated local inference and file editing in the explicitly approved
workspace. No general internet, GitHub, shell tool, autonomous host QA or
release approval. This candidate has NOT passed Devnet Master QA.
"""
from __future__ import annotations

import argparse
import http.client
import http.server
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import socketserver
import stat
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

VERSION = "0.1.3"
HOME = Path.home()
WORKSPACE = Path('/mnt/devnet-ai/projects/devnet-ai-safe-workspace')
DATA = HOME / '.local/share/devnet-safe-ai'
STATE_HOME = DATA / 'opencode-home'
BIN = HOME / '.local/bin/devnet-safe-ai'
PLANNER = 'qwen3.5:9b'
CODER = 'qwen3-coder:30b'
MODEL_SET = {PLANNER, CODER}
ALLOWED_GET = {'/api/version', '/api/tags', '/v1/models'}
ALLOWED_POST = {'/v1/chat/completions', '/api/chat', '/api/generate', '/api/show'}
MAX_BODY = 4 * 1024 * 1024


class Blocked(RuntimeError):
    pass


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise Blocked(reason)


def paths_safe() -> None:
    require(os.geteuid() != 0, 'Refusing root / sudo execution')
    require(WORKSPACE.is_dir() and not WORKSPACE.is_symlink(), 'Approved workspace not available')
    require(WORKSPACE.resolve() == WORKSPACE, 'Workspace has symlinked parents')
    require(WORKSPACE.stat().st_uid == os.getuid(), 'Workspace owner is unexpected')
    # The agent must never see the full parent directory; only this bind mount.
    require(not WORKSPACE.samefile(HOME), 'Workspace cannot be home')
    for program in ('bwrap', 'socat', 'opencode', 'ollama', 'curl'):
        require(shutil.which(program) is not None, f'Missing required program: {program}')


def private_dir(path: Path) -> None:
    if path.is_symlink():
        raise Blocked(f'Unsafe symlink directory: {path}')
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    require(path.stat().st_uid == os.getuid(), f'Unexpected owner: {path}')
    os.chmod(path, 0o700)


def memory_ok() -> None:
    mem = Path('/proc/meminfo').read_text()
    line = next((l for l in mem.splitlines() if l.startswith('MemAvailable:')), None)
    require(line is not None, 'Could not determine available RAM')
    kb = int(line.split()[1]); require(kb >= 10 * 1024 * 1024, 'Less than 10 GiB MemAvailable')


def gaming_now() -> bool:
    flags = HOME / '.config/devnet-qa-automation'
    if (flags / 'stop-all').exists() or (flags / 'gaming-on').exists():
        return True
    agent = HOME / '.local/lib/devnet-qa-automation/agent.py'
    # The existing trusted Devnet game guard is mandatory and runs on host only.
    if agent.is_symlink() or not agent.is_file():
        raise Blocked('Trusted Devnet gaming guard missing: fail closed')
    try:
        spec = importlib.util.spec_from_file_location('devnet_safe_existing_game_guard', agent)
        if spec is None or spec.loader is None:
            raise RuntimeError('cannot load guard')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        check = getattr(module, 'gaming_now', None)
        if not callable(check):
            raise RuntimeError('gaming_now missing')
        return bool(check())
    except Exception as error:
        raise Blocked(f'Cannot check gaming state: {type(error).__name__}') from error


def config() -> dict:
    # Independent, immutable-in-sandbox config. Don't load host OpenCode config:
    # doing so would expose credentials and allow pre-existing risky permissions.
    deny = [
        {'action': '*', 'resource': '*', 'effect': 'deny'},
        {'action': 'read', 'resource': '*', 'effect': 'allow'},
        {'action': 'glob', 'resource': '*', 'effect': 'allow'},
        {'action': 'grep', 'resource': '*', 'effect': 'allow'},
        # V2 checks location-relative edit resources such as main.py.
        # The independent external_directory deny and bwrap enforce workspace.
        {'action': 'edit', 'resource': '*', 'effect': 'allow'},
        {'action': 'edit', 'resource': '/home/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/run/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/tmp/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/usr/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/etc/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/proc/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '/dev/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '.opencode/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*/.opencode/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '.git/*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*/.git/*', 'effect': 'deny'},
        {'action': 'subagent', 'resource': 'devnet-heavy', 'effect': 'allow'},
        {'action': 'external_directory', 'resource': '*', 'effect': 'deny'},
        {'action': 'read', 'resource': '*.env*', 'effect': 'deny'},
        {'action': 'read', 'resource': '*.pem', 'effect': 'deny'},
        {'action': 'read', 'resource': '*id_ed25519*', 'effect': 'deny'},
        {'action': 'read', 'resource': '*id_rsa*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*.env*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*.pem', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*id_ed25519*', 'effect': 'deny'},
        {'action': 'edit', 'resource': '*id_rsa*', 'effect': 'deny'},
        {'action': 'shell', 'resource': '*', 'effect': 'deny'},
        {'action': 'webfetch', 'resource': '*', 'effect': 'deny'},
        {'action': 'websearch', 'resource': '*', 'effect': 'deny'},
    ]
    system = (
        'You are the Devnet 9B coordinator operating in a private offline sandbox. '
        'Handle simple questions, planning and easy code edits yourself. '
        'For genuinely complex multi-file coding, software architecture and hard debugging, '
        'autonomously delegate to devnet-heavy using the real subagent tool. '
        'NEVER supply a model argument to the subagent; let its configured 30B model run. '
        'Never pretend that delegation, a file edit, a test, or Master QA happened. '
        'Only read/write under /workspace, using location-relative file paths, ' 'never attempt external files, commands, '
        'network access or GitHub. Preserve originals. Create new revisions instead of '
        'overwriting established releases. Do NOT execute generated apps: GitHub-hosted '
        'Master QA is required first. Report anything untested honestly. '
        'Do not create or edit .opencode configuration, .git hooks or secret files.'
    )
    return {
        'model': 'ollama/' + PLANNER,
        'default_agent': 'build',
        'providers': {'ollama': {'settings': {'baseURL': 'http://127.0.0.1:11434/v1'}}},
        'policies': [
            {'action': 'provider.use', 'resource': '*', 'effect': 'deny'},
            {'action': 'provider.use', 'resource': 'ollama', 'effect': 'allow'},
            {'action': 'tool.use', 'resource': 'shell:*', 'effect': 'deny'},
            {'action': 'tool.use', 'resource': 'webfetch:*', 'effect': 'deny'},
            {'action': 'tool.use', 'resource': 'websearch:*', 'effect': 'deny'},
            {'action': 'tool.use', 'resource': 'execute:*', 'effect': 'deny'},
            {'action': 'integration.connect', 'resource': '*', 'effect': 'deny'},
            {'action': 'integration.use', 'resource': '*', 'effect': 'deny'},
            {'action': 'mcp.use', 'resource': '*', 'effect': 'deny'},
            {'action': 'plugin.use', 'resource': '*', 'effect': 'deny'},
            {'action': 'skill.use', 'resource': '*', 'effect': 'deny'},
        ],
        'permissions': deny,
        'agents': {
            'build': {'system': system, 'steps': 12},
            'devnet-heavy': {
                'mode': 'subagent', 'model': 'ollama/' + CODER,
                'description': 'Complex engineering and multi-file coding specialist. Use sparingly.',
                'steps': 8,
                'permissions': [
                    {'action': 'subagent', 'resource': '*', 'effect': 'deny'},
                    {'action': 'shell', 'resource': '*', 'effect': 'deny'},
                    {'action': 'webfetch', 'resource': '*', 'effect': 'deny'},
                    {'action': 'websearch', 'resource': '*', 'effect': 'deny'},
                ],
            },
        },
        'update': 'disable', 'snapshots': False, 'formatter': False, 'lsp': False,
    }


def inference_payload(method: str, target: str, payload: bytes) -> bytes:
    """Normalize only the 9B OpenAI-compatible chat body, on the trusted host.

    Some Ollama thinking-model streams return only `reasoning` to V2
    OpenCode, yielding zero content and zero tool calls.  The local Ollama
    /v1 handler accepts top-level reasoning_effort=none, but V2 model settings
    aren't reliably forwarded by all adapter versions. Keep tools/messages
    intact; do not alter other models or native Ollama endpoints.
    """
    if method == 'POST' and target == '/v1/chat/completions':
        data = json.loads(payload)
        if data['model'] == PLANNER:
            data['reasoning_effort'] = 'none'
            return json.dumps(data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    return payload


def allowed_http(method: str, target: str, payload: bytes) -> bool:
    # Exact path+method allowlist. All traffic is forwarded only to host loopback
    # Ollama, never to a URL supplied by an AI request.
    parsed = urlsplit(target)
    if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:
        return False
    if method == 'GET':
        return not payload and parsed.path in ALLOWED_GET
    if method != 'POST' or parsed.path not in ALLOWED_POST:
        return False
    if not payload or len(payload) > MAX_BODY:
        return False
    try:
        data = json.loads(payload)
    except (ValueError, UnicodeError):
        return False
    if not isinstance(data, dict):
        return False
    model = data.get('model', data.get('name'))
    if model not in MODEL_SET:
        return False
    # Respect the verified 30-second Ollama idle-memory policy. An API client
    # must not override it with an unlimited or longer keep_alive request.
    if 'keep_alive' in data and data['keep_alive'] not in ('30s', '0s', 0):
        return False
    # Reject remote images and file paths in Ollama multimodal requests; local
    # model inference only (not an arbitrary host-side URL or file fetcher).
    def unsafe_image(item):
        if isinstance(item, dict):
            return any((k in ('images', 'image_url') and unsafe_image(v))
                       or unsafe_image(v) for k, v in item.items())
        if isinstance(item, list):
            return any(unsafe_image(v) for v in item)
        if isinstance(item, str):
            return item.startswith(('http://', 'https://', 'file://'))
        return False
    if unsafe_image(data.get('images', [])) or unsafe_image(data.get('messages', [])):
        return False
    return True


class OllamaGateway(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'DevnetLocalGateway/0.1.1'
    sys_version = ''

    def log_message(self, fmt, *args):
        # No prompt or private request content logged.
        pass

    def do_GET(self):
        self.forward('GET')

    def do_POST(self):
        self.forward('POST')

    def do_PUT(self):
        self.fail(403)

    def do_DELETE(self):
        self.fail(403)

    def do_CONNECT(self):
        self.fail(403)

    def fail(self, code: int):
        self.send_response(code)
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.close_connection = True

    def forward(self, method: str):
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            self.fail(400); return
        if size < 0 or size > MAX_BODY or self.headers.get('Transfer-Encoding'):
            self.fail(413); return
        payload = self.rfile.read(size) if size else b''
        if not allowed_http(method, self.path, payload):
            self.fail(403); return
        # Inference request normalization occurs only *after* allowlist checks.
        # Enforce the body cap again after inserting the one fixed field.
        try:
            payload = inference_payload(method, self.path, payload)
        except (ValueError, UnicodeError, KeyError, TypeError):
            self.fail(400); return
        if len(payload) > MAX_BODY:
            self.fail(413); return
        conn = http.client.HTTPConnection('127.0.0.1', 11434, timeout=240)
        try:
            conn.request(method, self.path, body=payload,
                         headers={'Content-Type': 'application/json',
                                  'Accept': self.headers.get('Accept', 'application/json'),
                                  'Connection': 'close'})
            response = conn.getresponse()
            self.send_response(response.status)
            ctype = response.getheader('Content-Type')
            if ctype:
                self.send_header('Content-Type', ctype)
            # Always chunk outbound to handle both Ollama JSON and SSE streams.
            self.send_header('Transfer-Encoding', 'chunked')
            self.send_header('Connection', 'close')
            self.end_headers()
            while True:
                block = response.read1(16384)
                if not block:
                    break
                self.wfile.write(f'{len(block):X}\r\n'.encode() + block + b'\r\n')
                self.wfile.flush()
            self.wfile.write(b'0\r\n\r\n')
            self.wfile.flush()
        except (OSError, http.client.HTTPException, BrokenPipeError):
            # A client may disconnect while inference is running.
            self.close_connection = True
        finally:
            conn.close()
            self.close_connection = True


class UnixHTTPServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    request_queue_size = 32


def start_gateway(sock: Path):
    server = UnixHTTPServer(str(sock), OllamaGateway)
    os.chmod(sock, 0o600)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def sandbox_cmd(sock: Path, conf: Path, action: str, prompt: str | None):
    require(action in ('doctor', 'chat', 'run'), 'Unknown sandbox action')
    # Verified bwrap layout from prior Devnet diagnostic; no host /home, /mnt,
    # network routes, SSH agent, session bus, or host environment variables.
    inner = (
        'socat TCP4-LISTEN:11434,bind=127.0.0.1,reuseaddr,fork '
        'UNIX-CONNECT:/run/ollama.sock >/dev/null 2>&1 & '
        'sleep .5; '
        'curl -fsS --max-time 10 http://127.0.0.1:11434/api/tags >/dev/null || exit 11; '
    )
    if action == 'doctor':
        inner += (
            'test -z "$(find /home -mindepth 1 -maxdepth 1 ! -name agent -print -quit)" && test ! -e /mnt/devnet-ai || exit 12; '
            'test -z "$(tail -n +2 /proc/net/route)" || exit 13; '
            'test -w /workspace || exit 14; '
            'opencode debug agents > /tmp/devnet-agent-debug.json || exit 15; '
            'grep -q devnet-heavy /tmp/devnet-agent-debug.json || exit 16; '
            'echo "PASS: OpenCode sandbox, offline network, private workspace, models and subagent config"'
        )
    elif action == 'chat':
        inner += 'exec opencode --standalone'
    else:
        inner += 'exec opencode run --standalone --agent build --model ollama/qwen3.5:9b "$1"'
    term = os.environ.get('TERM', 'xterm-256color')
    if term not in ('xterm', 'xterm-256color', 'screen', 'screen-256color',
                    'tmux', 'tmux-256color', 'linux', 'vt100'):
        term = 'xterm-256color'
    args = [
        'bwrap', '--unshare-all', '--die-with-parent', '--new-session',
        '--ro-bind', '/usr', '/usr',
        '--symlink', 'usr/lib', '/lib64', '--symlink', 'usr/lib', '/lib',
        '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp',
        '--tmpfs', '/home', '--dir', '/home/agent', '--dir', '/run',
        '--bind', str(STATE_HOME), '/home/agent',
        '--bind', str(WORKSPACE), '/workspace',
        '--ro-bind', str(sock), '/run/ollama.sock',
        '--ro-bind', str(conf), '/run/opencode.json',
        '--clearenv', '--setenv', 'HOME', '/home/agent',
        '--setenv', 'PATH', '/usr/bin:/bin',
        '--setenv', 'TERM', term,
        '--setenv', 'LANG', 'C.UTF-8',
        '--setenv', 'OPENCODE_CONFIG', '/run/opencode.json',
        '--setenv', 'XDG_CONFIG_HOME', '/home/agent/.config',
        '--chdir', '/workspace', '/usr/bin/sh', '-c', inner, 'devnet-sh',
    ]
    if action == 'run':
        args.append(prompt or '')
    return args


def stop_models():
    for model in (CODER, PLANNER):
        try:
            subprocess.run(['ollama', 'stop', model], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=15, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass


def run_sandbox(action: str, prompt: str | None = None) -> int:
    paths_safe()
    private_dir(DATA)
    private_dir(STATE_HOME)
    # Do not modify existing OpenCode or Ollama configs; separate private state.
    if action != 'doctor':
        require(not gaming_now(), 'Gaming/stop-all is active')
        memory_ok()
    with tempfile.TemporaryDirectory(prefix='devnet-safe-gateway-') as temp:
        root = Path(temp)
        os.chmod(root, 0o700)
        sock, conf = root / 'ollama.sock', root / 'opencode.json'
        conf.write_text(json.dumps(config(), indent=2) + '\n')
        os.chmod(conf, 0o600)
        server = start_gateway(sock)
        try:
            # Independently enforce endpoint allowlist before exposing socket.
            require(not allowed_http('POST', '/api/pull', b'{}'), 'Gateway deny test failed')
            require(not allowed_http('GET', 'https://example.com', b''), 'Gateway URL test failed')
            cmd = sandbox_cmd(sock, conf, action, prompt)
            process = subprocess.Popen(cmd, start_new_session=True)
            interrupted = False
            try:
                while process.poll() is None:
                    if action != 'doctor' and gaming_now():
                        interrupted = True
                        break
                    time.sleep(0.75)
                if interrupted:
                    stop_models()
                    raise Blocked('Gaming detected; sandbox stopped and models unloaded')
                return process.wait()
            except KeyboardInterrupt:
                return 130
            except Blocked:
                stop_models()
                raise
            finally:
                # Never let an unexpected guard error, Ctrl-C or TUI exit
                # leave a background OpenCode process running.
                if process.poll() is None:
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        process.wait(timeout=4)
                    except subprocess.TimeoutExpired:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        process.wait()
        finally:
            server.shutdown()
            server.server_close()


def install() -> int:
    paths_safe()
    private_dir(DATA)
    private_dir(STATE_HOME)
    if BIN.parent.is_symlink():
        raise Blocked('Unsafe launcher directory symlink')
    BIN.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    require(BIN.parent.stat().st_uid == os.getuid(), 'Unexpected launcher directory owner')
    source = Path(__file__).resolve()
    require(source.is_file(), 'Script source missing')
    if BIN.exists() or BIN.is_symlink():
        if BIN.is_file() and BIN.read_bytes() == source.read_bytes():
            print('ALREADY INSTALLED:', BIN)
        else:
            raise Blocked('Launcher already exists; refusing to overwrite: ' + str(BIN))
    else:
        # Atomic install; installer source retained untouched.
        fd, tmp = tempfile.mkstemp(prefix='.devnet-safe-ai-', dir=BIN.parent)
        try:
            with os.fdopen(fd, 'wb') as target:
                target.write(source.read_bytes())
                target.flush(); os.fsync(target.fileno())
            os.chmod(tmp, 0o700)
            os.replace(tmp, BIN)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        print('INSTALLED:', BIN)
    print('WORKSPACE:', WORKSPACE)
    print('PRIVATE STATE:', STATE_HOME)
    print('NETWORK: no direct access; local Ollama inference-only gateway')
    print('TOOLS: workspace read/edit only; shell, web and GitHub blocked')
    print('QA: NOT APPROVED (new launcher; GitHub-first/host Master QA pending)')
    print('Next command:', str(BIN), 'doctor')
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Devnet private local AI launcher, v' + VERSION)
    parser.add_argument('action', choices=('install', 'doctor', 'chat', 'run', 'status'))
    parser.add_argument('prompt', nargs='*', help='Text prompt for run')
    args = parser.parse_args(argv)
    if args.action == 'install':
        return install()
    if args.action == 'status':
        print('Devnet Safe AI', VERSION, '| workspace:', WORKSPACE)
        print('Model policy: 9B default, 30B specialist; Ollama controls idle memory')
        print('Isolation: enforced only for commands launched through this tool')
        print('No direct internet, GitHub or shell tools. Master QA: NOT APPROVED')
        return 0
    if args.action == 'run' and not args.prompt:
        raise Blocked('run requires a prompt')
    return run_sandbox(args.action, ' '.join(args.prompt) if args.prompt else None)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Blocked, OSError, subprocess.SubprocessError, ValueError) as exc:
        print('BLOCKED:', exc, file=sys.stderr)
        raise SystemExit(2)
