"""Lifecycle tests run a real install/uninstall with a fake systemctl and fake Wine under a disposable HOME."""
import os
from pathlib import Path
import pwd
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).parent

class InstallerTests(unittest.TestCase):
    def setUp(self):
        user=pwd.getpwnam('nobody')
        self.uid=user.pw_uid; self.gid=user.pw_gid
        self.work=Path(tempfile.mkdtemp(prefix='devnet-wine-install-',dir='/tmp'))
        self.addCleanup(lambda:shutil.rmtree(self.work,ignore_errors=True))
        self.work.chmod(0o755)
        self.home=self.work/'home'; self.home.mkdir()
        os.chown(self.home,self.uid,self.gid)
        prefix=self.home/'.autodesk_fusion/wineprefixes/default-2705-wine1110-test'
        prefix.mkdir(parents=True)
        wine=self.home/'.local/wine-runners/wine-11.10-staging-tkg-amd64/bin/wineserver'
        wine.parent.mkdir(parents=True)
        wine.write_text('#!/bin/sh\nexit 0\n'); wine.chmod(0o755)
        bindir=self.work/'bin'; bindir.mkdir()
        systemctl=bindir/'systemctl'
        systemctl.write_text('#!/bin/sh\ncase "$*" in *"--user"*) exit 0;; *) exit 1;; esac\n')
        systemctl.chmod(0o755)
        for path in (prefix,wine.parent,wine.parent.parent,wine.parent.parent.parent,prefix.parent,prefix.parent.parent,prefix.parent.parent.parent,self.home/'.local'):
            os.chown(path,self.uid,self.gid)
        os.chown(wine,self.uid,self.gid)
        self.env=os.environ.copy()
        self.env['HOME']=str(self.home)
        self.env['PATH']=str(bindir)+':'+self.env['PATH']
    def run_as_user(self,script):
        return subprocess.run(['runuser','-u','nobody','--','env',f'HOME={self.home}',f'PATH={self.env["PATH"]}','bash',str(ROOT/script)],env=self.env,capture_output=True,text=True)
    def test_install_uninstall_preserves_fusion_and_config(self):
        first=self.run_as_user('install.sh')
        self.assertEqual(first.returncode,0,(first.stdout,first.stderr))
        self.assertTrue((self.home/'.local/bin/devnet-wine-idle-cleaner').is_file())
        self.assertTrue((self.home/'.config/systemd/user/devnet-wine-idle-cleaner.timer').is_file())
        self.assertTrue((self.home/'.config/devnet-wine-idle-cleaner/prefixes.json').is_file())
        self.assertEqual(self.run_as_user('install.sh').returncode,2)
        last=self.run_as_user('uninstall.sh')
        self.assertEqual(last.returncode,0,(last.stdout,last.stderr))
        self.assertFalse((self.home/'.local/bin/devnet-wine-idle-cleaner').exists())
        self.assertTrue((self.home/'.config/devnet-wine-idle-cleaner/prefixes.json').exists())
        self.assertTrue((self.home/'.autodesk_fusion/wineprefixes/default-2705-wine1110-test').is_dir())
        self.assertTrue((self.home/'.local/wine-runners/wine-11.10-staging-tkg-amd64/bin/wineserver').is_file())
    def test_uninstall_refuses_changed_installed_file(self):
        self.assertEqual(self.run_as_user('install.sh').returncode,0)
        p=self.home/'.local/bin/devnet-wine-idle-cleaner'
        with p.open('a') as out:
            out.write('\n# user edit\n')
        self.assertEqual(self.run_as_user('uninstall.sh').returncode,2)
        self.assertTrue(p.exists())
    def test_install_refuses_existing_timer(self):
        p=self.home/'.config/systemd/user/devnet-wine-idle-cleaner.timer'
        p.parent.mkdir(parents=True)
        p.write_text('preexisting\n')
        os.chown(self.home/'.config',self.uid,self.gid); os.chown(p.parent,self.uid,self.gid); os.chown(p,self.uid,self.gid)
        self.assertEqual(self.run_as_user('install.sh').returncode,2)
        self.assertEqual(p.read_text(),'preexisting\n')
    def test_install_refuses_existing_config(self):
        p=self.home/'.config/devnet-wine-idle-cleaner/prefixes.json'
        p.parent.mkdir(parents=True)
        p.write_text('preexisting\n')
        os.chown(self.home/'.config',self.uid,self.gid); os.chown(p.parent,self.uid,self.gid); os.chown(p,self.uid,self.gid)
        self.assertEqual(self.run_as_user('install.sh').returncode,2)
        self.assertEqual(p.read_text(),'preexisting\n')

if __name__=='__main__':
    unittest.main(verbosity=2)
