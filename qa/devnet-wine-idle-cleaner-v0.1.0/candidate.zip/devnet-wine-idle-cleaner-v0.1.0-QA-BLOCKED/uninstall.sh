#!/usr/bin/env bash
set -Eeuo pipefail
[[ $(id -u) -ne 0 ]] || { echo 'ERROR: do not use sudo'; exit 2; }
manifest="$HOME/.local/share/devnet-wine-idle-cleaner/install-manifest.sha256"
[[ -f "$manifest" && ! -L "$manifest" ]] || { echo "ERROR: no trusted install manifest; refusing removal"; exit 2; }
sha256sum -c --status "$manifest" || { echo "ERROR: installed files changed; refusing removal"; exit 2; }
systemctl --user disable --now devnet-wine-idle-cleaner.timer || true
for f in "$HOME/.local/bin/devnet-wine-idle-cleaner" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.service" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.timer"; do
    [[ ! -L "$f" ]] || { echo "ERROR: symlink detected, refusing to delete $f"; exit 2; }
    rm -f -- "$f"
done
rm -f -- "$manifest"
systemctl --user daemon-reload
printf '%s\n' 'UNINSTALLED: Wine cleaner code and timer removed.' 'Your Wine prefixes, Fusion files, cleaner state/configuration, and existing Devnet AI remain unchanged.'
