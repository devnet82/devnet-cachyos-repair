# Devnet Wine Idle Cleaner v0.1.0 — QA BLOCKED

Purpose: avoid lingering Autodesk Fusion 360 Wine core services keeping Devnet Safe AI paused after Fusion closes. Does NOT change Devnet's gaming detector or OpenCode configuration.

- Only **Fusion's explicitly configured WINEPREFIX** is monitored. Other Wine prefixes are untouched.
- One user-level systemd timer runs roughly once per minute; **no root/sudo** required.
- If a non-core process (`Fusion360.exe`, other `.exe`, `wine`, etc.) is detected in the prefix, cleanup is forbidden and the idle timer resets.
- If **only** the six known core service names remain in the prefix, and the same process identities persist for 180 seconds across scans, the final recheck may run `WINEPREFIX=<Fusion-prefix> <Wine-runner>/wineserver -k`.
- If process inspection, prefix, Wine runner, systemd, clock or PID identity cannot be verified, **do not kill**.
- An application launched at the last instant after the final scan remains a theoretical race; install only after user accepts this risk. No approach based on `/proc` snapshots can guarantee zero race.
- The watcher does not inspect window titles, log command lines or transmit data. It keeps a private small local timer state file.
- If a real app is running headlessly under a core service process name, the watcher may not recognise it. Only enable if this case does not apply to your prefix.

The unit deliberately uses the shared `/tmp` namespace (Wine uses `/tmp/.wine-UID` Unix sockets); isolating it with `PrivateTmp` would break prefix-scoped shutdown.

## Safe diagnostic before installation

`python3 monitor.py status` — read-only, no Wine termination.

## Installation — ONLY after complete independent Master QA approval

`bash install.sh`

## Uninstall/rollback

`bash uninstall.sh` — preserves Fusion prefix, Wine data, private configuration and logs. User may then manually remove orphaned config/state if desired. Does not touch Devnet Safe AI.

## QA release gate

20/20 offline behavioural and disposable-user installation/rollback tests PASS (current candidate only). Real CachyOS VM, systemd lifecycle, installer/rollback, Fusion window and headless app lifecycle, exact-prefix live shutdown, unrelated prefix isolation, sleep/resume race, and Devnet Safe AI continued gating **NOT TESTED**. **MASTER_QA=BLOCKED; RELEASE_APPROVED=false**. Do not enable on user host before full genuine evidence.
