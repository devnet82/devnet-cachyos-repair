#!/usr/bin/env bash
# Devnet Wine Idle Cleaner v0.1.0 — only for an approved QA release.
set -Eeuo pipefail
[[ $(id -u) -ne 0 ]] || { echo 'ERROR: run as desktop user, never with sudo'; exit 2; }
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
sha256sum -c SHA256SUMS
command -v systemctl >/dev/null
command -v python3 >/dev/null
[[ -d "$HOME/.autodesk_fusion/wineprefixes/default-2705-wine1110-test" ]] || { echo 'ERROR: Fusion Wine prefix missing'; exit 2; }
[[ -x "$HOME/.local/wine-runners/wine-11.10-staging-tkg-amd64/bin/wineserver" ]] || { echo 'ERROR: configured Wine runner missing'; exit 2; }
mkdir -p "$HOME/.local/bin" "$HOME/.config/systemd/user" "$HOME/.config/devnet-wine-idle-cleaner" "$HOME/.local/state/devnet-wine-idle-cleaner" "$HOME/.local/share/devnet-wine-idle-cleaner"
chmod 0700 "$HOME/.local/state/devnet-wine-idle-cleaner" "$HOME/.local/share/devnet-wine-idle-cleaner"
for f in "$HOME/.local/bin/devnet-wine-idle-cleaner" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.service" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.timer"; do
    [[ ! -e "$f" && ! -L "$f" ]] || { echo "ERROR: refusing to overwrite existing $f"; exit 2; }
done
if [[ -e "$HOME/.local/share/devnet-wine-idle-cleaner/install-manifest.sha256" ]]; then
    echo "ERROR: existing install manifest; refusing to overwrite"; exit 2
fi
if [[ -e "$HOME/.config/devnet-wine-idle-cleaner/prefixes.json" ]]; then
    echo 'ERROR: existing Wine cleaner configuration; refusing to overwrite'; exit 2
fi
install -m 0755 monitor.py "$HOME/.local/bin/devnet-wine-idle-cleaner"
install -m 0644 devnet-wine-idle-cleaner.service "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.service"
install -m 0644 devnet-wine-idle-cleaner.timer "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.timer"
python3 - <<'PY'
import json,os,pathlib
home=pathlib.Path.home()
p=home/'.config/devnet-wine-idle-cleaner/prefixes.json'
fd=os.open(str(p),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
with os.fdopen(fd,'w') as f:
    json.dump({'prefix':str(home/'.autodesk_fusion/wineprefixes/default-2705-wine1110-test'),
               'wineserver':str(home/'.local/wine-runners/wine-11.10-staging-tkg-amd64/bin/wineserver')},f,sort_keys=True)
    f.write('\n')
PY
manifest="$HOME/.local/share/devnet-wine-idle-cleaner/install-manifest.sha256"
sha256sum "$HOME/.local/bin/devnet-wine-idle-cleaner" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.service" "$HOME/.config/systemd/user/devnet-wine-idle-cleaner.timer" > "$manifest"
chmod 0600 "$manifest"
systemctl --user daemon-reload
systemctl --user enable --now devnet-wine-idle-cleaner.timer
systemctl --user is-active --quiet devnet-wine-idle-cleaner.timer
printf '%s\n' 'INSTALLED: Fusion-only Wine idle cleanup timer enabled' 'DELAY: 180 seconds after only safe-core Wine services remain (plus timer granularity)' 'Never shuts down while non-core Wine processes are detected.'
