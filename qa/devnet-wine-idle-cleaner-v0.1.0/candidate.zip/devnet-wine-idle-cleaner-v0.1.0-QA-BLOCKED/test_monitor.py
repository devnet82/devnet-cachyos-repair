import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import Mock

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location("winecleaner", ROOT / "monitor.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class DecisionTests(unittest.TestCase):
    core = [(100, "wineserver", "10"), (101, "services.exe", "11")]
    def test_no_wine(self):
        self.assertEqual(m.decision([], {}, 10)[0], "NO_WINE")
    def test_active_app_protects(self):
        self.assertEqual(m.decision(self.core+[(102,"fusion360.exe","12")], {"snapshot":[],"since":1}, 500)[0],"APP_RUNNING")
    def test_unknown_exe_protects(self):
        self.assertEqual(m.decision(self.core+[(102,"myapp.exe","12")], {}, 500)[0],"APP_RUNNING")
    def test_no_server_blocks(self):
        self.assertEqual(m.decision([(101,"services.exe","11")], {}, 10)[0],"NO_SERVER")
    def test_180_second_grace(self):
        status, state=m.decision(self.core,{},100)
        self.assertEqual(status,"WAITING")
        self.assertEqual(m.decision(self.core,state,279)[0],"WAITING")
        self.assertEqual(m.decision(self.core,state,280)[0],"READY")
    def test_service_restart_resets_grace(self):
        _,state=m.decision(self.core,{},100)
        other=[(100,"wineserver","12"),(101,"services.exe","11")]
        self.assertEqual(m.decision(other,state,500)[0],"WAITING")
    def test_clock_backwards_resets(self):
        _,state=m.decision(self.core,{},100)
        self.assertEqual(m.decision(self.core,state,99)[0],"WAITING")
    def test_reappearing_app_clears_idle(self):
        _,state=m.decision(self.core,{},100)
        self.assertEqual(m.decision(self.core+[(103,"game.exe","13")],state,500),("APP_RUNNING",{}))

class ProcessTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.prefix=self.root/"fusion"
        self.other=self.root/"other"
        self.prefix.mkdir(); self.other.mkdir()
        self.proc=self.root/"proc"; self.proc.mkdir()
    def task(self, pid, comm, prefix, tick="123"):
        p=self.proc/str(pid); p.mkdir()
        (p/"comm").write_text(comm+'\n')
        (p/"environ").write_bytes(f"HOME=/home/test\0WINEPREFIX={prefix}\0".encode())
        (p/"stat").write_text(f"{pid} ({comm}) S " + "0 "*18 + tick + " 0 0\n")
        return p
    def test_only_matching_prefix_selected(self):
        self.task(101,"wineserver",self.prefix)
        self.task(102,"fusion360.exe",self.other)
        self.assertEqual([(x[0],x[1]) for x in m.prefix_processes(self.prefix,self.proc)],[(101,"wineserver")])
    def test_windows_process_detected(self):
        self.task(101,"wineserver",self.prefix)
        self.task(103,"Fusion360.exe",self.prefix)
        self.assertEqual(m.decision(m.prefix_processes(self.prefix,self.proc),{},0)[0],"APP_RUNNING")
    def test_unreadable_wine_fails_closed(self):
        self.task(101,"wineserver",self.prefix)
        original=Path.read_bytes
        def fail_read(p):
            if str(p).endswith("/101/environ"):
                raise PermissionError("test")
            return original(p)
        from unittest.mock import patch
        with patch.object(Path,"read_bytes",fail_read):
            with self.assertRaises(RuntimeError):
                m.prefix_processes(self.prefix,self.proc)
    def test_missing_proc_fails_closed(self):
        with self.assertRaises(RuntimeError):
            m.prefix_processes(self.prefix,self.root/"missing")
    def test_status_does_not_run_wineserver_or_create_state(self):
        self.task(101,"wineserver",self.prefix)
        runner=Mock()
        result=m.execute_once(self.prefix,self.root/"unused",self.root/"state",do_kill=False,proc_root=self.proc,runner=runner)
        self.assertEqual(result,"WAITING"); runner.assert_not_called()
        self.assertFalse((self.root/"state").exists())
    def test_execute_waits_then_stops_exact_prefix(self):
        self.task(101,"wineserver",self.prefix)
        server=self.root/"wineserver"; server.write_text("#!/bin/sh\n"); server.chmod(0o700)
        runner=Mock(return_value=Mock(returncode=0))
        state=self.root/"state"
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=100,proc_root=self.proc,runner=runner),"WAITING")
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=279,proc_root=self.proc,runner=runner),"WAITING")
        runner.assert_not_called()
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=280,proc_root=self.proc,runner=runner),"STOP_REQUESTED")
        self.assertEqual(runner.call_count,1)
        args,kwargs=runner.call_args
        self.assertEqual(args[0],[str(server.resolve()),"-k"])
        self.assertEqual(kwargs["env"]["WINEPREFIX"],str(self.prefix.resolve()))
    def test_app_started_during_grace_no_stop(self):
        self.task(101,"wineserver",self.prefix)
        server=self.root/"wineserver"; server.write_text("ok"); server.chmod(0o700)
        runner=Mock()
        state=self.root/"state"
        m.execute_once(self.prefix,server,state,do_kill=True,now=100,proc_root=self.proc,runner=runner)
        self.task(102,"Fusion360.exe",self.prefix)
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=900,proc_root=self.proc,runner=runner),"APP_RUNNING")
        runner.assert_not_called()
    def test_missing_server_never_kills(self):
        self.task(101,"wineserver",self.prefix)
        runner=Mock()
        self.assertEqual(m.execute_once(self.prefix,self.root/"none",self.root/"state",do_kill=True,now=100,proc_root=self.proc,runner=runner),"SERVER_MISSING")
        runner.assert_not_called()

if __name__=="__main__":
    unittest.main(verbosity=2)
