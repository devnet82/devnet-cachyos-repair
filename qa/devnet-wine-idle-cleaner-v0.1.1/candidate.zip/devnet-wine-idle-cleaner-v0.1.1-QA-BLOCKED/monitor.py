#!/usr/bin/env python3
"""Prefix-isolated cleanup of abandoned Wine service-only sessions.

No Wine process is stopped while any unrecognised/interactive Wine process is present.
QA CANDIDATE: do not enable until full Master QA approval.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

VERSION = "0.1.1"
IDLE_SECONDS = 180
CORE = frozenset({"wineserver", "services.exe", "winedevice.exe", "svchost.exe", "plugplay.exe", "rpcss.exe"})
# These four are known residual Fusion Wine helpers. Each must also have an
# exact recognisable invocation; a process name on its own is NEVER sufficient.
# Linux truncates /proc/<pid>/comm to 15 bytes, so ADP and Edge names are short.
HELPER_NAMES = frozenset({"explorer.exe", "adpclientservic", "conhost.exe", "microsoftedgeup"})
VERIFIED_HELPERS = frozenset({"helper:" + name for name in HELPER_NAMES})


def verified_helper(name: str, raw: bytes) -> bool:
    """Recognise only observed persistent helper command lines; fail closed otherwise."""
    if name not in HELPER_NAMES or not raw:
        return False
    try:
        parts = [part.decode("utf-8", "surrogateescape") for part in raw.split(b"\0") if part]
        cmd = " ".join(parts).casefold().strip()
    except (ValueError, UnicodeError):
        return False
    if name == "explorer.exe":
        return cmd == r"c:\windows\system32\explorer.exe /desktop"
    if name == "conhost.exe":
        return cmd.startswith(r"c:\windows\system32\conhost.exe --server ") and cmd.endswith(" --headless")
    if name == "adpclientservic":
        return (cmd.startswith("c:\\program files\\autodesk\\webdeploy\\production\\")
                and "\\adpclientservice.exe -f c:\\users\\" in cmd and cmd.endswith(r"\appdata\roaming\autodesk\adpsdk\json"))
    if name == "microsoftedgeup":
        return cmd == r"c:\program files (x86)\microsoft\edgeupdate\microsoftedgeupdate.exe /c"
    return False


DEFAULT_PREFIX = ".autodesk_fusion/wineprefixes/default-2705-wine1110-test"
DEFAULT_SERVER = ".local/wine-runners/wine-11.10-staging-tkg-amd64/bin/wineserver"


def config(home: Path) -> tuple[Path, Path]:
    path = home / ".config/devnet-wine-idle-cleaner/prefixes.json"
    if not path.exists():
        return (home / DEFAULT_PREFIX, home / DEFAULT_SERVER)
    conf = json.loads(path.read_text(encoding="utf-8"))
    if set(conf) != {"prefix", "wineserver"}:
        raise ValueError("config fields must be exactly prefix and wineserver")
    for key in ("prefix", "wineserver"):
        if not isinstance(conf[key], str) or not conf[key].startswith(str(home) + "/"):
            raise ValueError("both paths must be absolute paths under the user home")
    return Path(conf["prefix"]), Path(conf["wineserver"])


def prefix_processes(prefix: Path, proc_root: Path = Path("/proc"), uid: int | None = None):
    """Return [(pid,comm,start_ticks)] with verified helpers marked helper:NAME."""
    if uid is None:
        uid = os.getuid()
    if not proc_root.is_dir():
        raise RuntimeError("procfs unavailable")
    target = os.path.realpath(prefix)
    matches = []
    for task in proc_root.iterdir():
        if not task.name.isdecimal():
            continue
        try:
            if task.stat().st_uid != uid:
                continue
            comm = (task / "comm").read_text(errors="replace").strip().lower()
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise RuntimeError("cannot inspect process ownership/name") from exc
        # Only same-prefix processes are selected. Never examine or output arguments.
        try:
            raw = (task / "environ").read_bytes()
        except FileNotFoundError:
            continue
        except OSError as exc:
            # Do not risk killing a Wine session if Wine task visibility is restricted.
            if comm in CORE or comm.endswith(".exe") or "wine" in comm:
                raise RuntimeError("Wine process environment not readable") from exc
            continue
        envs = raw.split(b"\0")
        values = [a[11:].decode("utf-8", "surrogateescape") for a in envs if a.startswith(b"WINEPREFIX=")]
        if not values or os.path.realpath(values[0]) != target:
            continue
        try:
            start = (task / "stat").read_text().rsplit(")", 1)[1].split()[19]
        except FileNotFoundError:
            continue
        except (OSError, IndexError) as exc:
            raise RuntimeError("cannot verify matching process start time") from exc
        if comm in HELPER_NAMES:
            try:
                raw_cmdline = (task / "cmdline").read_bytes()
            except FileNotFoundError:
                continue  # process exited while scanning; second scan protects the decision
            except OSError as exc:
                raise RuntimeError("cannot verify helper command line") from exc
            if verified_helper(comm, raw_cmdline):
                comm = "helper:" + comm
        matches.append((int(task.name), comm, start))
    return sorted(matches)


def decision(processes, old: dict, now: float, delay: int = IDLE_SECONDS):
    """Pure scheduling logic. Service PIDs changing or an app appearing resets grace period."""
    if not processes:
        return "NO_WINE", {}
    servers = [x for x in processes if x[1] == "wineserver"]
    if len(servers) != 1:
        return "NO_SERVER", {}
    # A previous run must have observed an app within THIS exact Wine-server
    # lifetime, not a different session that restarted between timer checks.
    identity = f"{servers[0][0]}:{servers[0][2]}"
    active = [x for x in processes if x[1] not in CORE | VERIFIED_HELPERS]
    if active:
        return "APP_RUNNING", {"app_observed": True, "wine_identity": identity}
    if old.get("app_observed") is not True or old.get("wine_identity") != identity:
        return "NOT_ARMED", {}
    snapshot = [f"{p}:{n}:{t}" for p, n, t in processes]
    if old.get("snapshot") != snapshot or not isinstance(old.get("since"), (int, float)):
        return "WAITING", {"snapshot": snapshot, "since": now, "app_observed": True, "wine_identity": identity}
    elapsed = now - old["since"]
    if elapsed < 0:
        return "WAITING", {"snapshot": snapshot, "since": now, "app_observed": True, "wine_identity": identity}
    if elapsed < delay:
        return "WAITING", old
    return "READY", old


def atomic_save(file: Path, data: dict):
    file.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(file.parent, 0o700)
    temp = file.with_suffix(".new")
    with temp.open("w", encoding="utf-8") as handle:
        os.chmod(temp, 0o600)
        json.dump(data, handle, sort_keys=True)
        handle.write("\n")
    temp.replace(file)


def execute_once(prefix: Path, server: Path, state_dir: Path, *, do_kill: bool, now: float | None = None, proc_root: Path = Path("/proc"), uid: int | None = None, runner=subprocess.run):
    if not prefix.is_dir():
        return "PREFIX_MISSING"
    if do_kill and (not server.is_file() or not os.access(server, os.X_OK)):
        return "SERVER_MISSING"
    now = time.time() if now is None else now
    state_file = state_dir / (hashlib.sha256(os.path.realpath(prefix).encode()).hexdigest()[:24] + ".json")
    # status mode should be fully read-only; timer tick takes exclusive lock.
    if not do_kill:
        try:
            processes = prefix_processes(prefix, proc_root, uid)
        except (RuntimeError, OSError):
            return "INSPECTION_BLOCKED"
        try:
            old = json.loads(state_file.read_text()) if state_file.exists() else {}
        except (OSError, ValueError):
            old = {}
        return decision(processes, old, now)[0]
    state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(state_dir, 0o700)
    lock = state_dir / ".lock"
    with lock.open("a+") as handle:
        os.chmod(lock, 0o600)
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            old = json.loads(state_file.read_text()) if state_file.exists() else {}
        except (OSError, ValueError):
            old = {}
        try:
            processes = prefix_processes(prefix, proc_root, uid)
            code, new = decision(processes, old, now)
        except (RuntimeError, OSError):
            return "INSPECTION_BLOCKED"
        if code != "READY":
            atomic_save(state_file, new)
            return code
        # One more full scan before sending a signal to the prefix-specific server.
        try:
            again = prefix_processes(prefix, proc_root, uid)
            verify, _ = decision(again, old, now)
        except (RuntimeError, OSError):
            return "INSPECTION_BLOCKED"
        if verify != "READY" or again != processes:
            atomic_save(state_file, {})
            return "CHANGED_SKIP"
        try:
            env = os.environ.copy()
            env["WINEPREFIX"] = str(prefix.resolve())
            done = runner([str(server.resolve()), "-k"], env=env, timeout=25, check=False, capture_output=True)
        except (OSError, subprocess.TimeoutExpired):
            return "STOP_FAILED"
        if done.returncode:
            return "STOP_FAILED"
        atomic_save(state_file, {})
        return "STOP_REQUESTED"


def main(argv=None):
    parser = argparse.ArgumentParser(description="Conservative per-prefix Wine idle cleanup")
    parser.add_argument("action", choices=("status", "tick"))
    parser.add_argument("--execute", action="store_true", help="allow prefix-specific wineserver stop on tick")
    args = parser.parse_args(argv)
    if args.execute and args.action != "tick":
        parser.error("--execute requires tick")
    try:
        prefix, server = config(Path.home())
        result = execute_once(prefix, server, Path.home() / ".local/state/devnet-wine-idle-cleaner", do_kill=args.execute)
    except (OSError, ValueError, RuntimeError, BlockingIOError) as exc:
        print(f"WINE CLEANER: BLOCKED ({type(exc).__name__})")
        return 2
    print(f"WINE CLEANER: {result}")
    return 2 if result in ("INSPECTION_BLOCKED", "SERVER_MISSING", "STOP_FAILED") else 0


if __name__ == "__main__":
    sys.exit(main())
