import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import Mock

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location("winecleaner", ROOT / "monitor.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class DecisionTests(unittest.TestCase):
    core = [(100, "wineserver", "10"), (101, "services.exe", "11")]
    def test_no_wine(self):
        self.assertEqual(m.decision([], {}, 10)[0], "NO_WINE")
    def test_active_app_protects(self):
        self.assertEqual(m.decision(self.core+[(102,"fusion360.exe","12")], {"snapshot":[],"since":1}, 500)[0],"APP_RUNNING")
    def test_unknown_exe_protects(self):
        self.assertEqual(m.decision(self.core+[(102,"myapp.exe","12")], {}, 500)[0],"APP_RUNNING")
    def test_no_server_blocks(self):
        self.assertEqual(m.decision([(101,"services.exe","11")], {}, 10)[0],"NO_SERVER")
    def test_180_second_grace(self):
        status, state=m.decision(self.core,{"app_observed":True,"wine_identity":"100:10"},100)
        self.assertEqual(status,"WAITING")
        self.assertEqual(m.decision(self.core,state,279)[0],"WAITING")
        self.assertEqual(m.decision(self.core,state,280)[0],"READY")
    def test_service_restart_resets_grace(self):
        _,state=m.decision(self.core,{"app_observed":True,"wine_identity":"100:10"},100)
        other=[(100,"wineserver","12"),(101,"services.exe","11")]
        self.assertEqual(m.decision(other,state,500)[0],"NOT_ARMED")
    def test_clock_backwards_resets(self):
        _,state=m.decision(self.core,{"app_observed":True,"wine_identity":"100:10"},100)
        self.assertEqual(m.decision(self.core,state,99)[0],"WAITING")
    def test_reappearing_app_clears_idle(self):
        _,state=m.decision(self.core,{"app_observed":True,"wine_identity":"100:10"},100)
        self.assertEqual(m.decision(self.core+[(103,"game.exe","13")],state,500),
                         ("APP_RUNNING",{"app_observed":True,"wine_identity":"100:10"}))

class ObservedHelperTests(unittest.TestCase):
    core = [(100, "wineserver", "10"), (101, "services.exe", "11")]
    def test_no_unarmed_cleanup(self):
        self.assertEqual(m.decision(self.core, {}, 500)[0], "NOT_ARMED")
    def test_active_process_arms(self):
        self.assertEqual(m.decision(self.core+[(102,"fusion360.exe","12")], {}, 100),
                         ("APP_RUNNING", {"app_observed": True, "wine_identity":"100:10"}))
    def test_observed_session_waits_then_ready(self):
        _, armed = m.decision(self.core+[(102,"fusion360.exe","12")], {}, 100)
        code, idle = m.decision(self.core, armed, 200)
        self.assertEqual(code, "WAITING")
        self.assertEqual(m.decision(self.core,idle,379)[0], "WAITING")
        self.assertEqual(m.decision(self.core,idle,380)[0], "READY")
    def test_safe_leftovers_with_armed_state(self):
        processes=self.core+[(103,"helper:explorer.exe","13"), (104,"helper:adpclientservic","14"),
                             (105,"helper:conhost.exe","15"), (106,"helper:microsoftedgeup","16")]
        s,i=m.decision(processes,{"app_observed": True,"wine_identity":"100:10"},100)
        self.assertEqual(s,"WAITING")
        self.assertEqual(m.decision(processes,i,280)[0],"READY")
    def test_unverified_helper_blocks(self):
        self.assertEqual(m.decision(self.core+[(103,"explorer.exe","13")],
                                    {"app_observed": True},300)[0],"APP_RUNNING")
        self.assertEqual(m.decision(self.core+[(103,"helper:explorer.exe","13"), (104,"fusion360.exe","40")],
                                    {"app_observed": True},300)[0],"APP_RUNNING")
    def test_exact_commands_and_reject_spoofed(self):
        yes = {
            "explorer.exe": r"C:\windows\system32\explorer.exe /desktop",
            "adpclientservic": r"C:\Program Files\Autodesk\webdeploy\production\id\ADPClientService.exe -f C:\users\dave\AppData\Roaming\Autodesk\ADPSDK\JSON",
            "conhost.exe": r"C:\windows\system32\conhost.exe --server 0x3c --headless",
            "microsoftedgeup": r"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe /c",
        }
        for name,cmd in yes.items():
            with self.subTest(name=name):
                self.assertTrue(m.verified_helper(name,cmd.encode()+b"\0"))
                self.assertFalse(m.verified_helper(name,(cmd+" /extra").encode()+b"\0"))
                self.assertFalse(m.verified_helper(name,b""))
        self.assertFalse(m.verified_helper("fusion360.exe",b"explorer.exe /desktop"))
    def test_unknown_exe_always_blocks(self):
        ps=self.core+[(105,"helper:conhost.exe","55"),(106,"somegame.exe","66")]
        self.assertEqual(m.decision(ps,{"app_observed": True,"snapshot":[],"since":10},999)[0],"APP_RUNNING")
    def test_pid_reuse_and_restart_reset_after_arming(self):
        s,st=m.decision(self.core,{"app_observed":True,"wine_identity":"100:10"},100)
        self.assertEqual(s,"WAITING")
        self.assertEqual(m.decision(self.core+[(105,"helper:explorer.exe","8")],st,500)[0],"WAITING")
    def test_server_restarts_without_observed_app_stays_unarmed(self):
        state={"app_observed":True,"wine_identity":"100:10","snapshot":[],"since":1}
        restarted=[(100,"wineserver","42"),(101,"services.exe","11")]
        self.assertEqual(m.decision(restarted,state,999)[0],"NOT_ARMED")
    def test_ambiguous_server_never_stops(self):
        state={"app_observed":True,"wine_identity":"100:10","snapshot":[],"since":1}
        self.assertEqual(m.decision(self.core+[(200,"wineserver","20")],state,999)[0],"NO_SERVER")
    def test_wineserver_gone_and_new_session_fails_closed(self):
        self.assertEqual(m.decision([],{"app_observed":True},900)[0],"NO_WINE")
        self.assertEqual(m.decision(self.core,{},901)[0],"NOT_ARMED")

class ProcessTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.prefix=self.root/"fusion"
        self.other=self.root/"other"
        self.prefix.mkdir(); self.other.mkdir()
        self.proc=self.root/"proc"; self.proc.mkdir()
    def task(self, pid, comm, prefix, tick="123"):
        p=self.proc/str(pid); p.mkdir()
        (p/"comm").write_text(comm+'\n')
        (p/"environ").write_bytes(f"HOME=/home/test\0WINEPREFIX={prefix}\0".encode())
        (p/"cmdline").write_bytes(comm.encode()+b"\0")
        (p/"stat").write_text(f"{pid} ({comm}) S " + "0 "*18 + tick + " 0 0\n")
        return p
    def test_only_matching_prefix_selected(self):
        self.task(101,"wineserver",self.prefix)
        self.task(102,"fusion360.exe",self.other)
        self.assertEqual([(x[0],x[1]) for x in m.prefix_processes(self.prefix,self.proc)],[(101,"wineserver")])
    def test_verified_helper_only_if_correct_commandline(self):
        self.task(101,"wineserver",self.prefix)
        p=self.task(103,"explorer.exe",self.prefix)
        (p/"cmdline").write_bytes(b"C:\\windows\\system32\\explorer.exe /desktop\0")
        ps=m.prefix_processes(self.prefix,self.proc)
        self.assertIn((103,"helper:explorer.exe","123"),ps)
        (p/"cmdline").write_bytes(b"Fusion.exe /unsafe\0")
        self.assertIn((103,"explorer.exe","123"),m.prefix_processes(self.prefix,self.proc))
    def test_unreadable_helper_cmdline_fails_closed(self):
        self.task(103,"explorer.exe",self.prefix)
        from unittest.mock import patch
        original=Path.read_bytes
        def denied(p):
            if str(p).endswith("/103/cmdline"): raise PermissionError("denied")
            return original(p)
        with patch.object(Path,"read_bytes",denied):
            with self.assertRaises(RuntimeError):
                m.prefix_processes(self.prefix,self.proc)
    def test_windows_process_detected(self):
        self.task(101,"wineserver",self.prefix)
        self.task(103,"Fusion360.exe",self.prefix)
        self.assertEqual(m.decision(m.prefix_processes(self.prefix,self.proc),{},0)[0],"APP_RUNNING")
    def test_unreadable_wine_fails_closed(self):
        self.task(101,"wineserver",self.prefix)
        original=Path.read_bytes
        def fail_read(p):
            if str(p).endswith("/101/environ"):
                raise PermissionError("test")
            return original(p)
        from unittest.mock import patch
        with patch.object(Path,"read_bytes",fail_read):
            with self.assertRaises(RuntimeError):
                m.prefix_processes(self.prefix,self.proc)
    def test_missing_proc_fails_closed(self):
        with self.assertRaises(RuntimeError):
            m.prefix_processes(self.prefix,self.root/"missing")
    def test_status_does_not_run_wineserver_or_create_state(self):
        self.task(101,"wineserver",self.prefix)
        runner=Mock()
        result=m.execute_once(self.prefix,self.root/"unused",self.root/"state",do_kill=False,proc_root=self.proc,runner=runner)
        self.assertEqual(result,"NOT_ARMED"); runner.assert_not_called()
        self.assertFalse((self.root/"state").exists())
    def test_execute_waits_then_stops_exact_prefix(self):
        self.task(101,"wineserver",self.prefix)
        server=self.root/"wineserver"; server.write_text("#!/bin/sh\n"); server.chmod(0o700)
        runner=Mock(return_value=Mock(returncode=0))
        state=self.root/"state"
        self.task(102,"Fusion360.exe",self.prefix)
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=50,proc_root=self.proc,runner=runner),"APP_RUNNING")
        (self.proc/"102"/"environ").unlink(); (self.proc/"102"/"comm").unlink(); (self.proc/"102"/"stat").unlink(); (self.proc/"102"/"cmdline").unlink(); (self.proc/"102").rmdir()
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=100,proc_root=self.proc,runner=runner),"WAITING")
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=279,proc_root=self.proc,runner=runner),"WAITING")
        runner.assert_not_called()
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=280,proc_root=self.proc,runner=runner),"STOP_REQUESTED")
        self.assertEqual(runner.call_count,1)
        args,kwargs=runner.call_args
        self.assertEqual(args[0],[str(server.resolve()),"-k"])
        self.assertEqual(kwargs["env"]["WINEPREFIX"],str(self.prefix.resolve()))
    def test_app_started_during_grace_no_stop(self):
        self.task(101,"wineserver",self.prefix)
        server=self.root/"wineserver"; server.write_text("ok"); server.chmod(0o700)
        runner=Mock()
        state=self.root/"state"
        self.task(102,"Fusion360.exe",self.prefix)
        m.execute_once(self.prefix,server,state,do_kill=True,now=100,proc_root=self.proc,runner=runner)
        p=self.proc/"102"
        for name in ("comm","environ","cmdline","stat"): (p/name).unlink()
        p.rmdir()
        m.execute_once(self.prefix,server,state,do_kill=True,now=150,proc_root=self.proc,runner=runner)
        self.task(102,"Fusion360.exe",self.prefix)
        self.assertEqual(m.execute_once(self.prefix,server,state,do_kill=True,now=900,proc_root=self.proc,runner=runner),"APP_RUNNING")
        runner.assert_not_called()
    def test_missing_server_never_kills(self):
        self.task(101,"wineserver",self.prefix)
        runner=Mock()
        self.assertEqual(m.execute_once(self.prefix,self.root/"none",self.root/"state",do_kill=True,now=100,proc_root=self.proc,runner=runner),"SERVER_MISSING")
        runner.assert_not_called()

if __name__=="__main__":
    unittest.main(verbosity=2)
